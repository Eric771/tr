# -*- coding: utf-8 -*-
from thrift.transport import THttpClient
from thrift.protocol import TCompactProtocol
from SecondaryQrCodeLogin import *
from SecondaryQrCodeLogin.ttypes import *
import traceback, time, json

host = 'https://gxx.line.naver.jp'
qrEndpoint = '/acct/lgn/sq/v1'
verifierEndpoint = '/acct/lp/lgn/sq/v1'

def createSecondaryQrCodeLoginService(host, headers):
    transport = THttpClient.THttpClient(host)
    transport.setCustomHeaders(headers)
    protocol = TCompactProtocol.TCompactProtocol(transport)
    client = SecondaryQrCodeLoginService.Client(protocol)
    return client

def createSecondaryQrCodeLoginPermitNoticeService(host, headers):
    transport = THttpClient.THttpClient(host)
    transport.setCustomHeaders(headers)
    protocol = TCompactProtocol.TCompactProtocol(transport)
    client = SecondaryQrCodeLoginPermitNoticeService.Client(protocol)
    return client


# EXAMPLE HEADER { 'User-Agent': 'Line/5.21.3', 'X-Line-Application': 'DESKTOPWIN\t5.21.3\tVH-PC\t10.0;SECONDARY','x-lal': 'en_id'}

class NewLineQR(object):
    
    def ___init___(self, client=None,name=None,headerLine=None,cert=None):
      self.client = client 
      self.name = name
      self.headerLine = headerLine
      self.cert = cert
    
      url = host+qrEndpoint
      cok = json.loads(self.headerLine)
      headers = cok
      client = createSecondaryQrCodeLoginService(url, headers)
      session = client.createSession(CreateQrSessionRequest())
      session_id = session.authSessionId
      qrcode = client.createQrCode(CreateQrCodeRequest(session_id))
      self.client.FlaskRenderJson(qrcode.callbackUrl)
      url = host+verifierEndpoint
      headers = {
        'User-Agent': cok['User-Agent']
        'X-Line-Application': cok['X-Line-Application'],
        'X-Line-Access': session_id,
        'x-lal': cok['x-lal']
      }
      client_verif = createSecondaryQrCodeLoginPermitNoticeService(url, headers)
      qrverified = client_verif.checkQrCodeVerified(CheckQrCodeVerifiedRequest(session_id))
      if self.cert != None:
        certificate = self.cert
      try:
        client.verifyCertificate(VerifyCertificateRequest(session.authSessionId, certificate))
      except SecondaryQrCodeException as error:
        self.client.SendNotify(error)
        pincode = client.createPinCode(CreatePinCodeRequest(session.authSessionId))
        self.client.FlaskRenderJson(pincode.pinCode)
        client_verif.checkPinCodeVerified(CheckPinCodeVerifiedRequest(session.authSessionId))
      except Exception:
        traceback.print_exc()
      qrcodelogin = client.qrCodeLogin(QrCodeLoginRequest(session.authSessionId, 'VH-PC', True))
      self.client.FlaskRenderJson(qrcodelogin.accessToken)
      self.client.FlaskRenderJson(qrcodelogin.certificate)